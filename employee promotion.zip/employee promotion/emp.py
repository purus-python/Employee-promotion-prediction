from flask import Flask,request,redirect,render_template,url_for
import pickle




app=Flask(__name__)
@app.route('/',methods=['POST','GET'])
def save():
    if request.method == 'POST':
        #Load Model
        model = pickle.load(open('emp.h5','rb'))
        emp = request.form['employee_id']
        dept = request.form['department']
        reg = request.form['region']
        edu = request.form['education']
        gen = request.form['gender']
        rec = request.form['recruitment_channel']
        train = request.form['no_of_trainings']
        age = request.form['age']
        pyr = request.form['previous_year_rating']
        los = request.form['length_of_service']
        awards = request.form['awards_won']
        avg = request.form['avg_training_score']
        print(emp,dept,reg,edu,gen,rec,train,age,pyr,los,awards,avg)
        a=model.predict([[emp,dept,reg,edu,gen,rec,train,age,pyr,los,awards,avg]])
        if a[0] == 1:
            return render_template('promoted.html')
        else:
            return render_template('not_promoted.html')
    return render_template('index.html')


if __name__ == '__main__':
    app.run(debug=True)
        
    
